import { GoogleGenAI, Type } from "@google/genai";
import { Coords } from "../types";

// As per instructions, assume API_KEY is available in the environment.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

export const getLocationInfo = async (coords: Coords): Promise<{ locationName: string; emergencyNumber: string } | null> => {
    try {
      const prompt = `Based on the coordinates latitude ${coords.latitude} and longitude ${coords.longitude}, provide the general location name (like "City, Country") and the primary emergency services phone number for that country.`;
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              locationName: { type: Type.STRING, description: "A user-friendly location string, e.g., 'San Francisco, USA'." },
              emergencyNumber: { type: Type.STRING, description: "The primary emergency phone number for the country, e.g., '911'." },
            },
            required: ["locationName", "emergencyNumber"],
          },
        },
      });
      
      const data = JSON.parse(response.text);
      return data;
  
    } catch (error) {
      console.error("Error fetching location info:", error);
      return null;
    }
};


export const getSurvivalSteps = async (crisisType: string, coords: Coords | null): Promise<string> => {
  try {
    const locationContext = coords ? ` The user is at approximately latitude ${coords.latitude}, longitude ${coords.longitude}. Tailor the advice to this specific region if possible (e.g., building codes, common terrain).` : '';
    const prompt = `Provide immediate, clear, and concise survival steps for a ${crisisType}.${locationContext} Use markdown unordered lists. Focus on the most critical actions first. The tone should be calm and authoritative. Do not include a preamble or conclusion, just the steps.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });
    
    return response.text;
  } catch (error) {
    console.error("Error fetching survival steps:", error);
    return "Could not retrieve survival steps at this time. Please rely on official emergency guidelines.";
  }
};

export const getSafePointAdvice = async (crisisType: string, coords: Coords | null): Promise<string> => {
    try {
      const locationContext = coords ? ` The user is at approximately latitude ${coords.latitude}, longitude ${coords.longitude}. Tailor the advice to this region.` : '';
      const prompt = `For a ${crisisType}, what are the general characteristics of a safe location to seek shelter in?${locationContext} Give 3 short, actionable bullet points as a markdown list.`;
  
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
      });
      
      return response.text;
    } catch (error) {
      console.error("Error fetching safe point advice:", error);
      return "Could not retrieve safe point advice. General advice: move to higher ground in floods, open areas in earthquakes, and away from smoke in fires.";
    }
  };

export const getFurtherHelp = async (crisisType: string, coords: Coords | null): Promise<string> => {
    try {
        const locationInfo = coords ? ` The user's approximate location is latitude ${coords.latitude}, longitude ${coords.longitude}.` : '';
        const prompt = `A user is in a "${crisisType}" crisis.${locationInfo} They have followed initial survival steps and are requesting further help. Provide advanced survival tactics and advice on immediate aid coordination. Be specific and actionable. Use a markdown list.`;
  
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
        });
      
        return response.text;
    } catch (error) {
        console.error("Error fetching further help:", error);
        return "Could not retrieve advanced advice. Try to contact emergency services directly if possible.";
    }
};