import React from 'react';
import { LifeBuoyIcon, SpinnerIcon } from './Icons';

interface FurtherHelpProps {
  onGetHelp: () => void;
  advice: string | null;
  isLoading: boolean;
  error: string | null;
}

const InfoCard: React.FC<{title: string, icon: React.ReactNode, children: React.ReactNode}> = ({title, icon, children}) => (
    <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-lg p-4 h-full flex flex-col">
        <div className="flex items-center mb-3 text-lg font-semibold text-amber-400">
            {icon}
            <h3 className="ml-2">{title}</h3>
        </div>
        <div className="flex-grow">
            {children}
        </div>
    </div>
);

const parseMarkdownList = (text: string) => {
    return text.split('\n').map((line, index) => {
      const match = line.match(/^\s*[-*]\s(.+)/);
      if (match) {
        return (
          <li key={index} className="mb-2 pl-1 flex">
            <span className="mr-2 text-amber-400">-</span>
            <span>{match[1]}</span>
          </li>
        );
      }
      if (line.trim()) {
          return <p key={index} className="font-semibold mt-2">{line}</p>;
      }
      return null;
    }).filter(Boolean);
};

const FurtherHelp: React.FC<FurtherHelpProps> = ({ onGetHelp, advice, isLoading, error }) => {
  return (
    <InfoCard title="Advanced Assistance" icon={<LifeBuoyIcon className="w-6 h-6" />}>
      {isLoading && (
        <div className="flex justify-center items-center h-full">
          <SpinnerIcon className="w-8 h-8 animate-spin" />
          <p className="ml-4">Generating advanced tactics...</p>
        </div>
      )}
      {error && <p className="text-red-400">{error}</p>}
      
      {!isLoading && !error && advice && (
         <ul className="space-y-1 text-gray-200 list-inside">
            {parseMarkdownList(advice)}
        </ul>
      )}

      {!isLoading && !error && !advice && (
        <div className="text-center flex flex-col justify-center items-center h-full">
          <p className="text-gray-300 mb-4">For specific, complex situations, request advanced tactics or aid coordination advice.</p>
          <button
            onClick={onGetHelp}
            disabled={isLoading}
            className="
              px-6 py-3 font-semibold text-white bg-blue-600 rounded-lg
              hover:bg-blue-500 transition-colors duration-200
              flex items-center justify-center
              disabled:bg-gray-500 disabled:cursor-not-allowed
            "
          >
            <LifeBuoyIcon className="w-5 h-5 mr-2" />
            Request Further Help
          </button>
        </div>
      )}
    </InfoCard>
  );
};

export default FurtherHelp;
