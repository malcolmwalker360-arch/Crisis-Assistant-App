import React, { useState } from 'react';
import { Contact } from '../types';
import { UserPlusIcon, EditIcon, Trash2Icon, PhoneIcon } from './Icons';

interface ContactManagerProps {
  contacts: Contact[];
  onAdd: (contact: Omit<Contact, 'id'>) => void;
  onEdit: (contact: Contact) => void;
  onRemove: (id: string) => void;
}

const ContactForm: React.FC<{
    onSubmit: (contact: Omit<Contact, 'id'> | Contact) => void;
    onCancel: () => void;
    initialData?: Contact | null;
}> = ({ onSubmit, onCancel, initialData }) => {
    const [name, setName] = useState(initialData?.name || '');
    const [type, setType] = useState(initialData?.type || '');
    const [phone, setPhone] = useState(initialData?.phone || '');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (name && type && phone) {
            onSubmit({ ...(initialData || {}), name, type, phone } as Contact);
        }
    };

    return (
        <form onSubmit={handleSubmit} className="p-4 bg-slate-800 rounded-lg mt-4 space-y-4">
            <div>
                <label htmlFor="contact-name" className="block text-sm font-medium text-gray-300">Name</label>
                <input
                    id="contact-name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md p-2 text-white focus:ring-red-500 focus:border-red-500"
                    required
                />
            </div>
            <div>
                <label htmlFor="contact-type" className="block text-sm font-medium text-gray-300">Type (e.g., Family, Neighbor)</label>
                <input
                    id="contact-type"
                    type="text"
                    value={type}
                    onChange={(e) => setType(e.target.value)}
                    className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md p-2 text-white focus:ring-red-500 focus:border-red-500"
                    required
                />
            </div>
            <div>
                <label htmlFor="contact-phone" className="block text-sm font-medium text-gray-300">Phone Number</label>
                <input
                    id="contact-phone"
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md p-2 text-white focus:ring-red-500 focus:border-red-500"
                    placeholder="e.g., 555-123-4567"
                    required
                />
            </div>
            <div className="flex justify-end space-x-2">
                <button type="button" onClick={onCancel} className="px-4 py-2 bg-gray-600 hover:bg-gray-500 rounded-md text-white">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-blue-600 hover:bg-blue-500 rounded-md text-white">{initialData ? 'Save' : 'Add'}</button>
            </div>
        </form>
    );
};

const ContactManager: React.FC<ContactManagerProps> = ({ contacts, onAdd, onEdit, onRemove }) => {
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [editingContact, setEditingContact] = useState<Contact | null>(null);

    const handleEditClick = (contact: Contact) => {
        setEditingContact(contact);
        setIsFormOpen(true);
    };

    const handleAddClick = () => {
        setEditingContact(null);
        setIsFormOpen(true);
    };

    const handleFormSubmit = (contactData: Omit<Contact, 'id'> | Contact) => {
        if ('id' in contactData) {
            onEdit(contactData as Contact);
        } else {
            onAdd(contactData);
        }
        setIsFormOpen(false);
        setEditingContact(null);
    };

    const handleRemoveClick = (id: string) => {
        if (window.confirm('Are you sure you want to remove this contact?')) {
            onRemove(id);
        }
    };

    return (
        <div className="w-full">
            <h3 className="text-lg font-medium text-gray-300 mb-2 text-center">2. Manage Emergency Contacts</h3>
            <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4">
                <ul className="space-y-2">
                    {contacts.map(contact => (
                        <li key={contact.id} className="flex items-center justify-between bg-slate-700/50 p-2 rounded-md">
                            <div>
                                <p className="font-semibold">{contact.name}</p>
                                <p className="text-sm text-gray-400 flex items-center mt-1">
                                    {contact.type}
                                    <span className="mx-1.5">&middot;</span>
                                    <PhoneIcon className="w-3.5 h-3.5 mr-1 text-gray-500" />
                                    <span className="font-mono">{contact.phone}</span>
                                </p>
                            </div>
                            <div className="flex space-x-2">
                                <button onClick={() => handleEditClick(contact)} className="p-2 text-gray-300 hover:text-white"><EditIcon className="w-5 h-5" /></button>
                                <button onClick={() => handleRemoveClick(contact.id)} className="p-2 text-gray-300 hover:text-red-500"><Trash2Icon className="w-5 h-5" /></button>
                            </div>
                        </li>
                    ))}
                </ul>
                {!isFormOpen && (
                    <button onClick={handleAddClick} className="w-full mt-4 flex items-center justify-center py-2 px-4 bg-green-600 hover:bg-green-500 rounded-md text-white font-semibold">
                        <UserPlusIcon className="w-5 h-5 mr-2" />
                        Add Contact
                    </button>
                )}
                {isFormOpen && (
                    <ContactForm 
                        onSubmit={handleFormSubmit}
                        onCancel={() => { setIsFormOpen(false); setEditingContact(null); }}
                        initialData={editingContact}
                    />
                )}
            </div>
        </div>
    );
};

export default ContactManager;