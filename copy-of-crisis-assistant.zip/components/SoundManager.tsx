import React, { useState, useEffect } from 'react';
import { CrisisType, CrisisSoundMap } from '../types';
import { Volume2Icon, PlayIcon } from './Icons';

interface SoundManagerProps {
  crisisType: CrisisType;
  soundMap: CrisisSoundMap;
  onSaveSound: (crisisType: CrisisType, soundUrl: string) => void;
}

const soundOptions = [
    { name: 'Default Siren', url: 'https://actions.google.com/sounds/v1/alarms/alarm_clock.ogg' },
    { name: 'Loud Horn', url: 'https://actions.google.com/sounds/v1/alarms/air_horn.ogg' },
    { name: 'Digital Beep', url: 'https://actions.google.com/sounds/v1/alarms/digital_watch_alarm_long.ogg' },
    { name: 'Bell Chime', url: 'https://actions.google.com/sounds/v1/alarms/medium_bell_ringing_near.ogg' },
];

const SoundManager: React.FC<SoundManagerProps> = ({ crisisType, soundMap, onSaveSound }) => {
    const [selectedSound, setSelectedSound] = useState<string>(soundMap[crisisType] || soundOptions[0].url);
    const [feedback, setFeedback] = useState<string>('');

    useEffect(() => {
        setSelectedSound(soundMap[crisisType] || soundOptions[0].url);
    }, [crisisType, soundMap]);

    const handleSave = () => {
        onSaveSound(crisisType, selectedSound);
        setFeedback(`Sound for ${crisisType} saved!`);
        setTimeout(() => setFeedback(''), 2000);
    };

    const playPreview = () => {
        const audio = new Audio(selectedSound);
        audio.play().catch(e => console.error("Error playing preview:", e));
    };

    return (
        <div className="w-full">
            <h3 className="text-lg font-medium text-gray-300 mb-2 text-center">3. Set Alert Sound</h3>
            <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4">
                <label htmlFor="sound-select" className="block text-sm font-medium text-gray-400 mb-1">
                    Sound for <span className="font-bold text-amber-400">{crisisType}</span>
                </label>
                <div className="flex items-center space-x-2">
                    <select
                        id="sound-select"
                        value={selectedSound}
                        onChange={(e) => setSelectedSound(e.target.value)}
                        className="flex-grow p-2 bg-gray-700 border border-gray-600 rounded-md text-white focus:ring-red-500 focus:border-red-500"
                    >
                        {soundOptions.map(opt => (
                            <option key={opt.url} value={opt.url}>{opt.name}</option>
                        ))}
                    </select>
                    <button onClick={playPreview} title="Preview Sound" className="p-2 bg-gray-600 hover:bg-gray-500 rounded-md text-white">
                        <PlayIcon className="w-5 h-5"/>
                    </button>
                </div>
                <button 
                    onClick={handleSave}
                    className="w-full mt-4 flex items-center justify-center py-2 px-4 bg-blue-600 hover:bg-blue-500 rounded-md text-white font-semibold"
                >
                    <Volume2Icon className="w-5 h-5 mr-2" />
                    Save Sound Setting
                </button>
                {feedback && <p className="text-center text-green-400 text-sm mt-2">{feedback}</p>}
            </div>
        </div>
    );
};

export default SoundManager;
