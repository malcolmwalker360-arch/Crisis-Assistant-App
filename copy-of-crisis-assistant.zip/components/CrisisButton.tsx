
import React from 'react';
import { AlertTriangleIcon } from './Icons';

interface CrisisButtonProps {
  onActivate: () => void;
  disabled: boolean;
}

const CrisisButton: React.FC<CrisisButtonProps> = ({ onActivate, disabled }) => {
  return (
    <button
      onClick={onActivate}
      disabled={disabled}
      className="
        group relative w-full sm:w-80 h-20 flex justify-center items-center px-8 py-4 
        font-bold text-white text-xl uppercase tracking-widest
        bg-red-700 rounded-lg shadow-lg
        transition-all duration-300 ease-in-out
        hover:bg-red-600 hover:shadow-2xl hover:scale-105
        active:scale-100
        disabled:bg-gray-500 disabled:cursor-not-allowed disabled:scale-100 disabled:shadow-lg
      "
    >
      <span className="absolute top-0 left-0 w-full h-full bg-red-800 opacity-50 group-hover:opacity-0 transition-opacity duration-300 animate-pulse group-hover:animate-none"></span>
      <AlertTriangleIcon className="w-8 h-8 mr-4" />
      <span className="relative">Activate Alert</span>
    </button>
  );
};

export default CrisisButton;
