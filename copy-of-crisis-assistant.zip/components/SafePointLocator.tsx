import React, { useState, useEffect } from 'react';
import { CrisisType, Coords, Contact } from '../types';
import { getSafePointAdvice } from '../services/geminiService';
import { MapPinIcon, SpinnerIcon, CheckCircleIcon, BroadcastIcon, ShareIcon, StopCircleIcon, SirenIcon, FlagIcon, PhoneIcon } from './Icons';

interface SafePointLocatorProps {
  location: Coords | null;
  locationName?: string;
  error: string | null;
  crisisType: CrisisType;
  isSharing: boolean;
  onToggleSharing: () => void;
  contacts: Contact[];
  onReportDanger: () => void;
  onMarkLocation: (note: string) => void;
}

const InfoCard: React.FC<{title: string, icon: React.ReactNode, children: React.ReactNode}> = ({title, icon, children}) => (
    <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-lg p-4 h-full flex flex-col">
        <div className="flex items-center mb-3 text-lg font-semibold text-amber-400">
            {icon}
            <h3 className="ml-2">{title}</h3>
        </div>
        <div className="flex-grow flex flex-col space-y-4">{children}</div>
    </div>
);

const MarkLocationModal: React.FC<{onSave: (note: string) => void; onCancel: () => void;}> = ({ onSave, onCancel }) => {
    const [note, setNote] = useState('');
    
    const handleSave = () => {
        onSave(note || 'Location marked without a note.');
    };

    return (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
            <div className="bg-slate-800 rounded-lg p-6 w-full max-w-sm border border-slate-700">
                <h3 className="text-lg font-semibold mb-4">Add a Note to Marked Location</h3>
                <textarea
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    placeholder="e.g., 'Found water source', 'Shelter here', etc."
                    className="w-full h-24 p-2 bg-gray-700 border border-gray-600 rounded-md text-white focus:ring-2 focus:ring-red-500 focus:border-red-500"
                />
                <div className="flex justify-end space-x-2 mt-4">
                    <button onClick={onCancel} className="px-4 py-2 bg-gray-600 hover:bg-gray-500 rounded-md text-white">Cancel</button>
                    <button onClick={handleSave} className="px-4 py-2 bg-blue-600 hover:bg-blue-500 rounded-md text-white">Save Mark</button>
                </div>
            </div>
        </div>
    );
};

const SafePointLocator: React.FC<SafePointLocatorProps> = ({ 
    location, locationName, error, crisisType, isSharing, onToggleSharing, contacts, onReportDanger, onMarkLocation 
}) => {
    const [advice, setAdvice] = useState<string>('');
    const [isLoadingAdvice, setIsLoadingAdvice] = useState<boolean>(true);
    const [isUpdatingShareStatus, setIsUpdatingShareStatus] = useState(false);
    const [isMarkingLocation, setIsMarkingLocation] = useState(false);
    
    useEffect(() => {
        if (crisisType) {
            const fetchAdvice = async () => {
                setIsLoadingAdvice(true);
                const result = await getSafePointAdvice(crisisType, location);
                setAdvice(result);
                setIsLoadingAdvice(false);
            };
            fetchAdvice();
        }
    }, [crisisType, location]);

    const handleToggleClick = () => {
        setIsUpdatingShareStatus(true);
        setTimeout(() => {
            onToggleSharing();
            setIsUpdatingShareStatus(false);
        }, 750);
    };

    const handleMarkLocationSave = (note: string) => {
        onMarkLocation(note);
        setIsMarkingLocation(false);
    };

    const parseMarkdownList = (text: string) => {
        return text.split('\n').map((line, index) => {
          const match = line.match(/^\s*[-*]\s(.+)/);
          if (match) {
            return (
              <li key={index} className="mb-2 pl-1 flex">
                <span className="mr-2 text-amber-400">-</span>
                <span>{match[1]}</span>
              </li>
            );
          }
          if (line.trim()) { return <p key={index} className="font-semibold mt-2">{line}</p>; }
          return null;
        }).filter(Boolean);
      };

    return (
        <>
            {isMarkingLocation && <MarkLocationModal onSave={handleMarkLocationSave} onCancel={() => setIsMarkingLocation(false)} />}
            <InfoCard title="Location & Safety" icon={<MapPinIcon className="w-6 h-6" />}>
                <div>
                    <h4 className="font-bold text-gray-300 mb-2">Your Location:</h4>
                    {error && <p className="text-red-400">{error}</p>}
                    {location ? (
                        <div className="p-3 bg-slate-700/50 rounded-md text-sm">
                           {locationName && <p className="font-sans font-semibold text-white mb-1">{locationName}</p>}
                           <p className="font-mono">Lat: {location.latitude.toFixed(4)}, Lon: {location.longitude.toFixed(4)}</p>
                        </div>
                    ) : (
                        !error && <p>Fetching location...</p>
                    )}
                </div>

                {location && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                         <button
                            onClick={handleToggleClick}
                            disabled={isUpdatingShareStatus}
                            className={`w-full px-3 py-2 font-semibold text-white rounded-lg transition-all duration-200 flex items-center justify-center disabled:bg-gray-500 disabled:cursor-wait ${isSharing ? 'bg-red-600 hover:bg-red-500 animate-pulse' : 'bg-green-600 hover:bg-green-500'}`}
                        >
                            {isUpdatingShareStatus ? <SpinnerIcon className="w-5 h-5 animate-spin" /> : isSharing ? <><StopCircleIcon className="w-5 h-5 mr-2" /> Stop Live Sharing</> : <><ShareIcon className="w-5 h-5 mr-2" /> Share Live Location</>}
                        </button>
                        <button onClick={onReportDanger} className="w-full px-3 py-2 font-semibold text-white bg-orange-600 hover:bg-orange-500 rounded-lg transition-colors flex items-center justify-center">
                            <SirenIcon className="w-5 h-5 mr-2" /> Report Danger
                        </button>
                         <button onClick={() => setIsMarkingLocation(true)} className="w-full sm:col-span-2 px-3 py-2 font-semibold text-white bg-sky-600 hover:bg-sky-500 rounded-lg transition-colors flex items-center justify-center">
                            <FlagIcon className="w-5 h-5 mr-2" /> Mark This Location
                        </button>
                    </div>
                )}
                
                {isSharing && location && (
                    <div>
                        <h4 className="font-bold text-gray-300 mb-2 flex items-center">
                            <BroadcastIcon className="w-5 h-5 mr-2 text-green-400 animate-pulse" />
                            Live Location Sharing Active
                        </h4>
                        <div className="p-3 bg-slate-700/50 rounded-md">
                            <p className="text-sm text-gray-400 mb-2">Sharing with:</p>
                            <ul className="space-y-1">
                                {contacts.map((c) => (
                                    <li key={c.id} className="flex items-center justify-between text-gray-200">
                                        <div>
                                            <CheckCircleIcon className="w-4 h-4 mr-2 text-green-400 inline-block" />
                                            <span>{c.name}</span>
                                        </div>
                                        <span className="font-mono text-sm text-gray-400 flex items-center">
                                            <PhoneIcon className="w-4 h-4 mr-1.5 text-gray-500" />
                                            {c.phone}
                                        </span>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>
                )}

                <div className="flex-grow">
                    <h4 className="font-bold text-gray-300 mb-2">Safety Advice:</h4>
                    {isLoadingAdvice ? (
                        <div className="flex justify-center items-center h-24"><SpinnerIcon className="w-6 h-6 animate-spin" /></div>
                    ) : (
                        <ul className="space-y-1 text-gray-200 list-inside">{parseMarkdownList(advice)}</ul>
                    )}
                </div>
            </InfoCard>
        </>
    );
};

export default SafePointLocator;