import React from 'react';
import { DangerReport } from '../types';
import { SirenIcon, Trash2Icon } from './Icons';

interface DangerLogProps {
  reports: DangerReport[];
  isOnline: boolean;
  onClear: () => void;
}

const InfoCard: React.FC<{title: string, icon: React.ReactNode, children: React.ReactNode}> = ({title, icon, children}) => (
    <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-lg p-4 h-full flex flex-col">
        <div className="flex items-center mb-3 text-lg font-semibold text-amber-400">
            {icon}
            <h3 className="ml-2">{title}</h3>
        </div>
        <div className="flex-grow flex flex-col space-y-4">{children}</div>
    </div>
);

const DangerLog: React.FC<DangerLogProps> = ({ reports, isOnline, onClear }) => {
  return (
    <InfoCard title="Danger Log" icon={<SirenIcon className="w-6 h-6" />}>
      {reports.length > 0 ? (
        <>
          <div className="flex-grow space-y-2 overflow-y-auto max-h-48 pr-2">
            {reports.slice().reverse().map(report => (
              <div key={report.id} className="p-2 bg-slate-700/50 rounded-md">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-semibold">{report.crisisType}</p>
                    <p className="text-xs text-gray-400 font-mono">
                      Lat: {report.coords.latitude.toFixed(2)}, Lon: {report.coords.longitude.toFixed(2)}
                    </p>
                    <p className="text-xs text-gray-400">{new Date(report.timestamp).toLocaleString()}</p>
                  </div>
                  <span className={`px-2 py-1 text-xs rounded-full ${isOnline ? 'bg-green-500/20 text-green-300' : 'bg-yellow-500/20 text-yellow-300'}`}>
                    {isOnline ? 'Synced' : 'Pending Sync'}
                  </span>
                </div>
              </div>
            ))}
          </div>
          <button
            onClick={onClear}
            className="w-full mt-2 flex items-center justify-center py-2 px-4 bg-red-800 hover:bg-red-700 rounded-md text-white font-semibold text-sm"
          >
            <Trash2Icon className="w-4 h-4 mr-2" />
            Clear Log
          </button>
        </>
      ) : (
        <div className="flex-grow flex items-center justify-center">
            <p className="text-gray-400">No danger zones reported.</p>
        </div>
      )}
    </InfoCard>
  );
};

export default DangerLog;
