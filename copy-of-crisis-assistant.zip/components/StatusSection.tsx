import React, { useState, useEffect } from 'react';
import { AmbulanceIcon, CheckCircleIcon, SpinnerIcon, PhoneIcon } from './Icons';
import { Contact } from '../types';

interface StatusSectionProps {
    contacts: Contact[];
    isOnline: boolean;
}

const getHelpStatuses = (isOnline: boolean) => [
    { message: isOnline ? 'Sending alerts to emergency contacts...' : 'Queuing alerts (device is offline)...', icon: <SpinnerIcon className="w-5 h-5 animate-spin" /> },
    { message: 'Alerts processed successfully.', icon: <CheckCircleIcon className="w-5 h-5 text-green-400" /> },
    { message: 'Contacting local emergency services...', icon: <SpinnerIcon className="w-5 h-5 animate-spin" /> },
    { message: 'Help has been dispatched.', icon: <AmbulanceIcon className="w-5 h-5 text-blue-400" /> },
    { message: 'ETA: 15 minutes.', icon: <AmbulanceIcon className="w-5 h-5 text-blue-400 animate-pulse" /> },
];

const InfoCard: React.FC<{title: string, icon: React.ReactNode, children: React.ReactNode}> = ({title, icon, children}) => (
    <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-lg p-4 h-full">
        <div className="flex items-center mb-3 text-lg font-semibold text-amber-400">
            {icon}
            <h3 className="ml-2">{title}</h3>
        </div>
        {children}
    </div>
);


const StatusSection: React.FC<StatusSectionProps> = ({ contacts, isOnline }) => {
    const [currentStatusIndex, setCurrentStatusIndex] = useState(0);
    const helpStatuses = getHelpStatuses(isOnline);

    useEffect(() => {
        if (currentStatusIndex < helpStatuses.length - 1) {
            const timer = setTimeout(() => {
                setCurrentStatusIndex(prevIndex => prevIndex + 1);
            }, 3000); // 3 seconds per status update
            return () => clearTimeout(timer);
        }
    }, [currentStatusIndex, helpStatuses.length]);

    return (
        <InfoCard title="Help Status" icon={<AmbulanceIcon className="w-6 h-6" />}>
             <div className="space-y-4">
                <div>
                    <h4 className="font-bold text-gray-300 mb-2">Current Status:</h4>
                    <div className="flex items-center text-lg p-3 bg-slate-700/50 rounded-md">
                        {helpStatuses[currentStatusIndex].icon}
                        <p className="ml-3">{helpStatuses[currentStatusIndex].message}</p>
                    </div>
                </div>
                <div>
                    <h4 className="font-bold text-gray-300 mb-2">Alerted Contacts:</h4>
                    <ul className="space-y-2">
                        {contacts.map((contact) => (
                            <li key={contact.id} className="flex items-center justify-between text-gray-300">
                                <div>
                                    <CheckCircleIcon className={`w-5 h-5 mr-2 inline-block text-green-400`} />
                                    <span>{contact.name} ({contact.type})</span>
                                </div>
                                <span className="font-mono text-sm text-gray-400 flex items-center">
                                    <PhoneIcon className="w-4 h-4 mr-1.5 text-gray-500" />
                                    {contact.phone}
                                </span>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
        </InfoCard>
    );
};

export default StatusSection;