import React from 'react';
import { MarkedLocation } from '../types';
import { FlagIcon, Trash2Icon } from './Icons';

interface EmergencyLocatorProps {
  locations: MarkedLocation[];
  onClear: () => void;
}

const InfoCard: React.FC<{title: string, icon: React.ReactNode, children: React.ReactNode}> = ({title, icon, children}) => (
    <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-lg p-4 h-full flex flex-col">
        <div className="flex items-center mb-3 text-lg font-semibold text-amber-400">
            {icon}
            <h3 className="ml-2">{title}</h3>
        </div>
        <div className="flex-grow flex flex-col space-y-4">{children}</div>
    </div>
);

const EmergencyLocator: React.FC<EmergencyLocatorProps> = ({ locations, onClear }) => {
  return (
    <InfoCard title="Emergency Locator Log" icon={<FlagIcon className="w-6 h-6" />}>
      {locations.length > 0 ? (
        <>
          <div className="flex-grow space-y-2 overflow-y-auto max-h-48 pr-2">
            {locations.slice().reverse().map(loc => (
              <div key={loc.id} className="p-3 bg-slate-700/50 rounded-md">
                  <p className="font-semibold text-gray-200">"{loc.note}"</p>
                  <p className="text-xs text-gray-400 mt-1">{loc.crisisType}</p>
                  <p className="text-xs text-gray-400 font-mono">
                    Lat: {loc.coords.latitude.toFixed(3)}, Lon: {loc.coords.longitude.toFixed(3)}
                  </p>
                  <p className="text-xs text-gray-500 text-right">{new Date(loc.timestamp).toLocaleString()}</p>
              </div>
            ))}
          </div>
          <button
            onClick={onClear}
            className="w-full mt-2 flex items-center justify-center py-2 px-4 bg-red-800 hover:bg-red-700 rounded-md text-white font-semibold text-sm"
          >
            <Trash2Icon className="w-4 h-4 mr-2" />
            Clear Log
          </button>
        </>
      ) : (
        <div className="flex-grow flex items-center justify-center">
            <p className="text-gray-400">No locations marked yet.</p>
        </div>
      )}
    </InfoCard>
  );
};

export default EmergencyLocator;
