
import React, { useState, useEffect } from 'react';
import { CrisisType, Coords } from '../types';
import { getSurvivalSteps } from '../services/geminiService';
import { BookOpenIcon, SpinnerIcon } from './Icons';

interface SurvivalGuideProps {
  crisisType: CrisisType;
  location: Coords | null;
}

const InfoCard: React.FC<{title: string, icon: React.ReactNode, children: React.ReactNode}> = ({title, icon, children}) => (
    <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-lg p-4 h-full">
        <div className="flex items-center mb-3 text-lg font-semibold text-amber-400">
            {icon}
            <h3 className="ml-2">{title}</h3>
        </div>
        {children}
    </div>
);

const SurvivalGuide: React.FC<SurvivalGuideProps> = ({ crisisType, location }) => {
  const [steps, setSteps] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchSteps = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const result = await getSurvivalSteps(crisisType, location);
        setSteps(result);
      } catch (err) {
        setError('Failed to load survival steps.');
        console.error(err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchSteps();
  }, [crisisType, location]);

  const parseMarkdownList = (text: string) => {
    return text.split('\n').map((line, index) => {
      const match = line.match(/^\s*[-*]\s(.+)/);
      if (match) {
        return (
          <li key={index} className="mb-2 pl-1 flex">
            <span className="mr-2 text-amber-400">-</span>
            <span>{match[1]}</span>
          </li>
        );
      }
      if (line.trim()) {
          return <p key={index} className="font-semibold mt-2">{line}</p>;
      }
      return null;
    }).filter(Boolean);
  };

  return (
    <InfoCard title={`Survival Guide: ${crisisType}`} icon={<BookOpenIcon className="w-6 h-6" />}>
        {isLoading && (
            <div className="flex justify-center items-center h-48">
                <SpinnerIcon className="w-8 h-8 animate-spin" />
            </div>
        )}
        {error && <p className="text-red-400">{error}</p>}
        {!isLoading && !error && (
            <ul className="space-y-1 text-gray-200 list-inside">
                {parseMarkdownList(steps)}
            </ul>
        )}
    </InfoCard>
  );
};

export default SurvivalGuide;