import React from 'react';
import { QueuedMessage } from '../types';
import { MessageSquareIcon, Trash2Icon } from './Icons';

interface MessageQueueProps {
  messages: QueuedMessage[];
  onClear: () => void;
}

const InfoCard: React.FC<{title: string, icon: React.ReactNode, children: React.ReactNode}> = ({title, icon, children}) => (
    <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-lg p-4 h-full flex flex-col">
        <div className="flex items-center mb-3 text-lg font-semibold text-amber-400">
            {icon}
            <h3 className="ml-2">{title}</h3>
        </div>
        <div className="flex-grow flex flex-col space-y-4">{children}</div>
    </div>
);

const getStatusPill = (status: QueuedMessage['status']) => {
    switch (status) {
        case 'queued':
            return <span className="px-2 py-1 text-xs rounded-full bg-yellow-500/20 text-yellow-300">Queued</span>;
        case 'sending':
            return <span className="px-2 py-1 text-xs rounded-full bg-blue-500/20 text-blue-300 animate-pulse">Sending...</span>;
        case 'sent':
            return <span className="px-2 py-1 text-xs rounded-full bg-green-500/20 text-green-300">Sent</span>;
    }
}

const MessageQueue: React.FC<MessageQueueProps> = ({ messages, onClear }) => {
  return (
    <InfoCard title="Message Queue" icon={<MessageSquareIcon className="w-6 h-6" />}>
      {messages.length > 0 ? (
        <>
          <div className="flex-grow space-y-2 overflow-y-auto max-h-48 pr-2">
            {messages.slice().reverse().map(msg => (
              <div key={msg.id} className="p-3 bg-slate-700/50 rounded-md">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="font-semibold text-gray-200">{msg.contactName}</p>
                    <p className="text-xs text-gray-400 font-mono">{msg.contactPhone}</p>
                  </div>
                  {getStatusPill(msg.status)}
                </div>
                <p className="text-sm text-gray-300 bg-black/20 p-2 rounded-md">"{msg.message}"</p>
              </div>
            ))}
          </div>
          <button
            onClick={onClear}
            className="w-full mt-2 flex items-center justify-center py-2 px-4 bg-gray-700 hover:bg-gray-600 rounded-md text-white font-semibold text-sm"
          >
            <Trash2Icon className="w-4 h-4 mr-2" />
            Clear Sent Messages
          </button>
        </>
      ) : (
        <div className="flex-grow flex items-center justify-center">
            <p className="text-gray-400">No outgoing messages in queue.</p>
        </div>
      )}
    </InfoCard>
  );
};

export default MessageQueue;
